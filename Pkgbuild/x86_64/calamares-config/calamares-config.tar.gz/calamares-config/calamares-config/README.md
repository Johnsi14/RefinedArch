# RefinedArch Calamares config
